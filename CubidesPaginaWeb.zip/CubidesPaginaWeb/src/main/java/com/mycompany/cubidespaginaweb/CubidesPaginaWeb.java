/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.cubidespaginaweb;

/**
 *
 * @author Juan Sebastian Cubides Gutiérrez
 */

import java.sql.*; 
import javax.swing.*; 
import java.awt.*; 
import java.sql.PreparedStatement; 

public class CubidesPaginaWeb {

    private static Connection connection; // Variable global

    public static void main(String[] args){ 
        conectarBaseDeDatos();  // Llamamos la función para conectarnos a la BD
    }
    
    private static void conectarBaseDeDatos() {
        // Realizamos la conexión con la BD dentro de SQL Server
        String conexionNexascore = "jdbc:sqlserver://172.30.30.35:1433;"
        + "databaseName=NEXASCORE;"
        + "user=root;"
        + "password=root;"
        + "encrypt = true;"
        + "trustServerCertificate=true;"; // Esta variable nos permitira tener la cadena de conexión a la BD
        
        try { // El Try - Catch nos permitira tener la posiblidad de capturar errores si se presentan
        connection = DriverManager.getConnection(conexionNexascore);
        System.out.println("La conexión fue correcta. Felicitaciones!!");
        }catch (SQLException e) {
            System.out.println("La conexión fue incorrecta. Lee el error y sigue intentando" + e.getMessage());
        }
    } 
    
    public static void insertarLibros(Connection connection){
        // Insertamos un libro donde su id se añadira de forma automática dentro de la BD
        String insertarLibro = "INSERT INTO LIBRO(Titulo, Autor, Fecha, ISBN) VALUES(?,?,?,?)";
        try{ // Ingreso de datos
             PreparedStatement stmt = connection.prepareStatement(insertarLibro);
             stmt.setString(1, "WEB 2");
             stmt.setString(2, "Sebastian Cubides");
             stmt.setString(3, "2025-02-15");
             stmt.setString(4, "14513");
             stmt.executeUpdate();
             System.out.println("El libro fue insertado correctamente");        
        }catch(SQLException e){
            System.out.println("Error al insertar el libro" + e.getMessage());
        }    
    }
    
    public static void leerLibro(Connection connection){
       //consulta para obtener solo el primer libro
       String consultaLibroSql = "SELECT TOP 100 Id_Libro, Autor, Titulo, Fecha, ISBN from libro";
       try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(consultaLibroSql)) {
           //Verificar si hay resultados y obterner el primer registro
           if(rs.next()) {
               int id = rs.getInt("Id_Libro");
               String nombre = rs.getString("Titulo");
               String autor = rs.getString("Autor");
               
               System.out.println("ID:" + id + ", Nombre" + nombre + ", Autor:" + autor);
           }else {               
               System.out.println("No se pudo leer ningun dato de la tabla LIBROS");
           }
       }catch (SQLException e) {
           System.out.println("Error al ejecutar la consulta: " + e.getMessage());
       }
    }
    
}
